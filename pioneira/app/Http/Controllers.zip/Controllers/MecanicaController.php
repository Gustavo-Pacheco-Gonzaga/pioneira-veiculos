<?php

namespace App\Http\Controllers;

use App\Models\Mecanica;

class MecanicaController extends Controller
{
    public function showMecanica()
    {
        return Mecanica::orderBy('qtd', 'DESC')->with('mecanicaEvento')->orderBy('nome', 'DESC')->get();
    }
}
