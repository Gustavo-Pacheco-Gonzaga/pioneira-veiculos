<?php

namespace App\Http\Controllers;

use App\Models\Cotacao;
use App\Models\Cotacao_observacao;
use App\Models\Reparo;
use Illuminate\Http\Request;

class CotacaoController extends Controller
{
    public function showAllCotacao()
    {
        return Cotacao::with('cotacaoEvento', 'cotacaoMecanica')->orderBy('created_at', 'DESC')->get();
    }

    public function showCotacaoById($id)
    {
        return Cotacao::where([
            'evento_id' => $id,
        ])->with(['cotacaoObservacao', 'cotacaoMecanica'])->get();
    }

    public function createCotacaoObservacao(Request $request)
    {
        $cotacaoObservacao = new Cotacao_observacao($request->all());
        $cotacaoObservacao->save();

        return $this->message('Observação criada com sucesso.', 200);
    }

    public function createReparo(Request $request)
    {
        $cotacao = Cotacao::where([
            'evento_id' => $request->get('evento_id')
        ])->get();
        for ($i = 0; $i < sizeof($cotacao); $i++) {
            $cotacao[$i]->update([
                'finalizado' => 1
            ]);
            $cotacao[$i]->save();
        }

        $reparo = new Reparo($request->all());
        $reparo->save();

        return $this->message('Item movido para a área de reparo.', 200);
    }

    public function message($m, $c)
    {
        return response()->json([
            'mensagem' => $m
        ], $c);
    }
}
