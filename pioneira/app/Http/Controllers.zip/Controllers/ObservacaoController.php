<?php

namespace App\Http\Controllers;

use App\Models\Cotacao_observacao;
use App\Models\Orcamento_observacao;
use App\Models\Reparo_complemento;
use App\Models\Reparo_observacao;

class ObservacaoController extends Controller
{
    public function showOrcamentoObservacao($id)
    {
        return Orcamento_observacao::where([
            'orcamento_id' => $id
        ])->get();
    }

    public function showCotacaoObservacao($id)
    {
        return Cotacao_observacao::where([
            'cotacao_id' => $id
        ])->get();
    }

    public function showReparoObservacao($id)
    {
        return Reparo_observacao::where([
            'reparo_id' => $id
        ])->get();
    }

    public function showReparoComplemento($id)
    {
        return Reparo_complemento::where([
            'reparo_id' => $id
        ])->get();
    }
}
